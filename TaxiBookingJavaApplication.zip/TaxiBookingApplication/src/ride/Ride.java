package ride;

public class Ride {
	private int rideId;
	private int customerId;
	private char fromPoint;
	private char toPoint;
	private int pickupTime;
	private int dropTime;
	private int fare;
	private int taxiId;
	public int getRideId() {
		return rideId;
	}
	public void setRideId(int rideId) {
		this.rideId = rideId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public char getFromPoint() {
		return fromPoint;
	}
	public void setFromPoint(char fromPoint) {
		this.fromPoint = fromPoint;
	}
	public char getToPoint() {
		return toPoint;
	}
	public void setToPoint(char toPoint) {
		this.toPoint = toPoint;
	}
	public int getPickupTime() {
		return pickupTime;
	}
	public void setPickupTime(int pickupTime) {
		this.pickupTime = pickupTime;
	}
	public int getDropTime() {
		return dropTime;
	}
	public void setDropTime(int dropTime) {
		this.dropTime = dropTime;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	public int getTaxiId() {
		return taxiId;
	}
	public void setTaxiId(int taxiId) {
		this.taxiId = taxiId;
	}
	public Ride(int rideId, int customerId, char fromPoint, char toPoint, int pickupTime, int dropTime, int fare,
			int taxiId) {
		super();
		this.rideId = rideId;
		this.customerId = customerId;
		this.fromPoint = fromPoint;
		this.toPoint = toPoint;
		this.pickupTime = pickupTime;
		this.dropTime = dropTime;
		this.fare = fare;
		this.taxiId = taxiId;
	}
	public Ride() {
		super();
	}
	
	
}
