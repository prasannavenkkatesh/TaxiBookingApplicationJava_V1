package ride;

public enum Point {
	A,B,C,D,E,F
	

}
