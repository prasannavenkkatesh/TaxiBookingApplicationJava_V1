package ride;

import java.util.ArrayList;

import java.util.List;
import java.util.Scanner;

import taxi.Taxi;
import taxi.TaxiService;

public class RideService {
	
	private static int customerId = 0;
	private static int rideId = 0;
	
	private static List<Ride> rides = new ArrayList<Ride>();
	
	TaxiService taxiService = new TaxiService();

	public void bookTaxi(List<Taxi> taxis) {
		
		Scanner input = new Scanner(System.in);
		
		RideService rideService = new RideService();
		
		System.out.println("Booking Portal Open, Press any key to continue...");
		char check = input.nextLine().charAt(0);
		System.out.println();
		while(check != 0) {
			System.out.println("Enter the From Point:");
			char fromPoint = input.nextLine().charAt(0);
			
			System.out.println("Enter the To Point:");
			char toPoint = input.nextLine().charAt(0);
			
			System.out.println("Enter the Pickup Time:");
			int pickupTime = input.nextInt();
			input.nextLine();
			
			List<Taxi> availableTaxis = null;
			availableTaxis =  taxiService.findTaxisAtThePoint( pickupTime,fromPoint, taxis);
			
			if(availableTaxis == null || availableTaxis.size() == 0) {
				availableTaxis = taxiService.findTaxisFromTheNearByPoint(pickupTime, fromPoint, taxis);
			}
			
			Taxi taxiToBeAssigned = null;
			if(availableTaxis.size() > 1) {
			taxiToBeAssigned =	taxiService.findTheLeastEarning(availableTaxis);
			System.out.println("LeastEarningTaxi----------> "+ taxiToBeAssigned.getTaxiId());
			}
			else if(availableTaxis.size() == 1 ) {
				taxiToBeAssigned = availableTaxis.get(0);
			}
			
			if(taxiToBeAssigned == null) {
				System.out.println("No taxis found for your ride... check another Location? Press 1 to continue Searching and 0 to exit Portal...");	
				check = (char) input.nextInt();
				continue;
			}
			else {
				System.out.println("Taxi Found For you...");
				System.out.println("Taxi Details: ");
				System.out.println("taxiId: "+ taxiToBeAssigned.getTaxiId()+" taxiCurrentPosition: "+taxiToBeAssigned.getCurPososition()) ;
				rideService.registerRide(++customerId, taxiToBeAssigned, fromPoint, toPoint, pickupTime, taxis);
				check = 0;
			}
		
			
			
		}
		
		
	}

	private void registerRide(int customerId, Taxi taxiToBeAssigned, char fromPoint, char toPoint, int pickupTime, List<Taxi> taxis ) {
		System.out.println("Please Confirm your Boooking By Pressing 1 Press 2 to cancel Ride");
		
		Scanner input = new Scanner(System.in);
		int bookingStatus = input.nextInt();
		input.nextLine();
		
		if(bookingStatus == 1) {
			System.out.println("Booking Confirmed... Getting your ride ready...");	System.out.println();
		
				
			char currentPositionOfTheTaxi = taxiToBeAssigned.getCurPososition();
			int ponitsToTravel = Math.abs(currentPositionOfTheTaxi - fromPoint);
			int timeToBetakenForReachingTheFromPoint = taxiToBeAssigned.getCurrrentTime() + (ponitsToTravel)*1;
//			taxiToBeAssigned.setCurrrentTime(taxiToBeAssigned.getCurrrentTime()+ timeToBetakenForReachingTheFromPoint);
			
			
			System.out.println("Taxi is At your Point... Press Any Key to continue...");
			char continueKey = input.nextLine().charAt(0);
			System.out.println();
			Ride ride = new Ride();
			ride.setRideId(++rideId);
			ride.setCustomerId(customerId);
			ride.setFromPoint(fromPoint);
			ride.setToPoint(toPoint);
			ride.setPickupTime(pickupTime);
			ride.setTaxiId(taxiToBeAssigned.getTaxiId());
			
			// Fare Calculation
			int pointToBeTravelledFromFromPointToToPoint = Math.abs(fromPoint - toPoint);
			int distanceTobeTravelled = pointToBeTravelledFromFromPointToToPoint *15;
			
			int fareForFirst5Kms = 100;
			distanceTobeTravelled = distanceTobeTravelled -5;
			int fareForRemainingDistance = distanceTobeTravelled*10;
			int totalFareOfRide = fareForFirst5Kms + fareForRemainingDistance;
			ride.setFare(totalFareOfRide);	
			
			//System.out.println(" taxisNewCurrentTime:"+taxisNewCurrentTime+" pointToBeTravelledFromFromPointToToPoint: "+pointToBeTravelledFromFromPointToToPoint);
			int taxisNewCurrentTime = pickupTime;
			int timeToBeTakenToReachTheToPoint = taxisNewCurrentTime + (pointToBeTravelledFromFromPointToToPoint)*1;
			taxiToBeAssigned.setCurrrentTime(timeToBeTakenToReachTheToPoint);
			taxiToBeAssigned.setTotalEarnings(taxiToBeAssigned.getTotalEarnings()+ totalFareOfRide);
			taxiToBeAssigned.setCurPososition(toPoint);
			

			ride.setDropTime(timeToBeTakenToReachTheToPoint);
			
			taxiService.updateTaxi(taxiToBeAssigned, taxis);
			rides.add(ride);
			
			//save taxi and save ride
			System.out.println("Thanks for your ride...");
			System.out.println();
		}
		else {
			System.out.println("Ride Cancelled...");
			System.out.println();
		}
		
	}

	public void listAllRides() {
		
		System.out.println("Listing All Rides...");
		for(Ride ride: rides) {
			System.out.println("rideId: "+ride.getRideId()+" customerId: "+ride.getCustomerId()+" taxiId: "+ride.getTaxiId()+" From: "+ride.getFromPoint()+" To: "+ride.getToPoint()+" pickupTime: "+ride.getPickupTime()+
					" dropTime: "+ride.getDropTime()+" rideFare: "+ride.getFare()+" ");
		}
		System.out.println();
		
	}

}
