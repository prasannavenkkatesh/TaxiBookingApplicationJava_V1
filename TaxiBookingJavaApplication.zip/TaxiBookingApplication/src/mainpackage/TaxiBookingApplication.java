package mainpackage;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import ride.RideService;
import taxi.Taxi;
import taxi.TaxiService;

public class TaxiBookingApplication {

	private static List<Taxi> taxis = new ArrayList<Taxi>();

	public static void main(String[] agrs) {

		System.out.println("Welcome to the Taxi Booking System, Press any key to continue...");

		Scanner input = new Scanner(System.in);
		TaxiService taxiService = new TaxiService();
		RideService rideService = new RideService();


		System.out.println("Press any key to start...");
		char start = input.nextLine().charAt(0);

		// Create Taxis of number n;
		int n = 5;

		taxiService.createTaxis(n, taxis);

//		taxis.addAll(createdTaxis);
		
		 System.out.println("Chooose 1 -> SHOW TAXIS        Choose 2 -> register"); 
		 int option = input.nextInt();

		while (option != 0) {

			switch (option) {

			case 1:

				taxiService.showAllTaxis(taxis);
				break;
				
			case 2: 
				rideService.bookTaxi(taxis);
				break;
			case 3:
				rideService.listAllRides();
				break;

			}
			
			
			System.out.println("Choose your next Activity: ");
			option = input.nextInt();

		}

	}

}
