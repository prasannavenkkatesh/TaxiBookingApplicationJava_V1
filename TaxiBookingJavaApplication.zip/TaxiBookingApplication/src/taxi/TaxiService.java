package taxi;

import java.util.ArrayList;
import java.util.Currency;
import java.util.List;

import ride.Ride;

public class TaxiService {

	private static int taxiId = 0;

	
	// 1. Create Taxis
	public static void createTaxis(int n, List<Taxi> taxis) {

		for (int i = 0; i < n; i++) {
			Taxi taxi = new Taxi(++taxiId, 'A', 6, 0, null);
			taxis.add(taxi);
		}
		System.out.println("Created " + n + " taxis");

	}
	
	

	// 2. Showing All Taxis
	public void showAllTaxis(List<Taxi> taxis) {
		System.out.println("Showing All taxis: ");
		for (Taxi curTaxi : taxis) {
			System.out.println(" taxiId: " + curTaxi.getTaxiId() + " currentPosition: " + curTaxi.getCurPososition()
					+ " currentTime: " + curTaxi.getCurrrentTime() + " totalEarnings: " + curTaxi.getTotalEarnings());
		}
		System.out.println();
	}

	public List<Taxi> findTaxisAtThePoint(int pickupTime, char fromPoint, List<Taxi> taxis) {
		System.out.println("Searching for taxis at your point....");System.out.println();
		List<Taxi> availableTaxis = new ArrayList<Taxi>();;
		for (Taxi taxi : taxis) {
			if (taxi.getCurPososition() == fromPoint && taxi.getCurrrentTime() <= pickupTime) {
				System.out.println(taxi.getCurPososition() +" "+fromPoint+" "+taxi.getCurrrentTime() +" "+pickupTime);
				availableTaxis.add(taxi);
			}
		}
		System.out.println(availableTaxis.size());
		return availableTaxis;
	}



	public List<Taxi> findTaxisFromTheNearByPoint(int pickupTime, char fromPoint, List<Taxi> taxis) {
		
		System.out.println("Couldnt Find Taxis at this point, Searching Nearby Locations...");System.out.println();
		List<Taxi> nearbyAvailableTaxis = new ArrayList<Taxi>();
		
		int min = Integer.MIN_VALUE;
		Taxi mostNearbyTaxi = null;
		for (Taxi taxi : taxis) {
			int curDifference = Math.abs(taxi.getCurPososition() - fromPoint);
			if(taxi.getCurrrentTime() <= pickupTime && curDifference > min && cabCanReachOnTime(pickupTime, fromPoint, taxi.getCurPososition(), taxi.getCurrrentTime())) {
			System.out.println("Checking for minimum...");
				min = curDifference;
				mostNearbyTaxi = taxi;	
			}
		
		}
		nearbyAvailableTaxis.add(mostNearbyTaxi);
		return nearbyAvailableTaxis;
	}



	private boolean cabCanReachOnTime(int pickupTime, char fromPoint, char curPososition, int currrentTime) {
		
		int timeToBeTaken = Math.abs(fromPoint - curPososition)*1 + currrentTime;
		
		if(timeToBeTaken <= pickupTime) {
			return true;
		}
		else {
			return false;
		}
		
	}

	public Taxi findTheLeastEarning(List<Taxi> taxis) {
		System.out.println("Found multiple taxis, Finding the Best one for you..."); System.out.println();
		int leastEarning = Integer.MAX_VALUE;
		Taxi leastEarningTaxi = null;
		for (Taxi taxi : taxis) {
			if (taxi.getTotalEarnings() < leastEarning) {
				leastEarningTaxi = taxi;
			}
		}

		return leastEarningTaxi;

	}



	public void updateTaxi(Taxi taxiToBeAssigned, List<Taxi> taxis) {
		
		taxis.set(taxiToBeAssigned.getTaxiId()-1, taxiToBeAssigned);
		System.out.println("Taxi Updated Successfully...");
		
	}

}
