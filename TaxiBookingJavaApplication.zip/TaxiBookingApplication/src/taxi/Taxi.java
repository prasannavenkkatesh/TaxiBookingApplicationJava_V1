package taxi;

import java.util.List;

import ride.Ride;

public class Taxi {

	private int taxiId;
	private char curPososition;
	private int currrentTime;
	private int totalEarnings;
	private List<Ride> rides;
	public int getTaxiId() {
		return taxiId;
	}
	public void setTaxiId(int taxiId) {
		this.taxiId = taxiId;
	}
	public char getCurPososition() {
		return curPososition;
	}
	public void setCurPososition(char curPososition) {
		this.curPososition = curPososition;
	}
	public int getCurrrentTime() {
		return currrentTime;
	}
	public void setCurrrentTime(int currrentTime) {
		this.currrentTime = currrentTime;
	}
	public int getTotalEarnings() {
		return totalEarnings;
	}
	public void setTotalEarnings(int totalEarnings) {
		this.totalEarnings = totalEarnings;
	}
	public List<Ride> getRides() {
		return rides;
	}
	public void setRides(List<Ride> rides) {
		this.rides = rides;
	}
	public Taxi(int taxiId, char curPososition, int currrentTime, int totalEarnings, List<Ride> rides) {
		super();
		this.taxiId = taxiId;
		this.curPososition = curPososition;
		this.currrentTime = currrentTime;
		this.totalEarnings = totalEarnings;
		this.rides = rides;
	}
	public Taxi() {
		super();
	}

	
	
	
}
